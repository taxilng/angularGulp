'use strict';
var OFFLINE = false;


/*******************21开发环境*******************************/
// var ROOT_URL = 'http://10.10.10.21:8080';
// var ROUTE_URL = 'ifp_backEndProxy/proxy.json'                                       //前置路径


/*******************poc ngix*******************************/
// var ROOT_URL = 'http://webapp.hoperun.com:8802';
// var ROUTE_URL = 'ifp_backEndProxy/proxy.json'                                     //前置路径
// var UPLOAD_IMAGELOG_URL = "/cashier_desk/upload/";									 //图片上传路径
// var DOWNLOAD_IMAGELOG_URL = "http://10.10.102.99:8800";								 //图片下载地址
// var DOWNLOAD_IMAGELOG_PATH = "/image/bankicon/";									 //图片下载路径
// var DOWNLOAD_IMAGELOGO_PATH = "/image/logo/";


/*******************33 ngix环境*******************************/

// var ROOT_URL = 'http://10.10.6.33:8802';
// var ROUTE_URL = 'ifp_backEndProxy/proxy.json'                                     //前置路径
// var UPLOAD_IMAGELOG_URL = "/cashier_desk/upload/";									 //图片上传路径
// var DOWNLOAD_IMAGELOG_URL = "http://10.10.6.33:8800";								 //图片下载地址
// var DOWNLOAD_IMAGELOG_PATH = "/image/bankicon/";									 //图片下载路径
// var DOWNLOAD_IMAGELOGO_PATH = "/image/logo/";


/*******************21 ngix环境*******************************/
// var ROOT_URL = 'http://10.10.10.21:8802';
// var ROUTE_URL = 'ifp_backEndProxy/proxy.json'                                        //前置路径
// var UPLOAD_IMAGELOG_URL = "/cashier_desk/upload/";									 //图片上传路径
// var DOWNLOAD_IMAGELOG_URL = "http://10.10.10.21:8800";								 		 //图片下载地址
// var DOWNLOAD_IMAGELOG_PATH = "/image/bankicon/";
// var DOWNLOAD_IMAGELOGO_PATH = "/image/logo/";    								 //图片下载路径

/*******************uat ngix环境*******************************/
var ROOT_URL = 'http://10.10.7.100:8802';
var ROUTE_URL = 'ifp_backEndProxy/proxy.json'                                     //前置路径
var UPLOAD_IMAGELOG_URL = "/cashier_desk/upload/";									 //图片上传路径
var DOWNLOAD_IMAGELOG_URL = "http://10.10.7.100:8800";								 //图片下载地址
var DOWNLOAD_IMAGELOG_PATH = "/image/bankicon/";									 //图片下载路径
var DOWNLOAD_IMAGELOGO_PATH = "/image/logo/";
